﻿//Grading ID: N7591
//Lab Number 9
//Due 4/21/2019
//Course Section 199-75
//This program will update a date based on what the user inputs.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab09
{
    public partial class DateForm : Form
    {
        private Date startDate = new Date(1, 1, 2000);

        public DateForm()
        {
            InitializeComponent();
        }

        private void DateForm_Load(object sender, EventArgs e)
        {
            outputLbl.Text = $"{startDate}";
        }

        private void monthBtn_Click(object sender, EventArgs e)
        {
            int m; //Month input

            if (int.TryParse(monthTxt.Text, out m))
            {
                startDate.Month = m;
                outputLbl.Text = $"{startDate}";
                monthTxt.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid month.");
                monthTxt.Clear();
            }
        }

        private void dayBtn_Click(object sender, EventArgs e)
        {
            int d; //day input

            if (int.TryParse(dayTxt.Text, out d))
            {
                startDate.Day = d;
                outputLbl.Text = $"{startDate}";
                dayTxt.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid day.");
                dayTxt.Clear();
            }
        }

        private void yearBtn_Click_1(object sender, EventArgs e)
        {
            int y; //year input

            if (int.TryParse(yearTxt.Text, out y))
            {
                startDate.Year = y;
                outputLbl.Text = $"{startDate}";
                yearTxt.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid year.");
                yearTxt.Clear();
            }
        }
    }
}
