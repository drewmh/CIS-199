﻿//Grading ID: N7591
//Lab Number 9
//Due 4/21/2019
//Course Section 199-75
//This program will update a date based on what the user inputs.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class Date
    {
        private int _month; // Month 1-12
        private int _day; // Day 1-31
        private int _year; // Year >=0

        public Date(int m=1, int d=1, int y=2000)
        {
            Month = m; //variable
            Day = d; //variable
            Year = y; //variable
        }

        public int Month
        {
            get
            {
                return _month;
            }

            set
            {
                if (value >= 1 && value < 13)
                    _month = value;
                else
                    _month = 1;
            }
        }

        public int Day
        {
            get
            {
                return _day;
            }

            set
            {
                if (value >= 1 && value < 32)
                    _day = value;
                else
                    _day = 1;
            }
        }

        public int Year
        {
            get
            {
                return _year;
            }

            set
            {
                if (value >= 0)
                    _year = value;
                else
                    _year = 2019;
            }
        }

        public override string ToString()
        {
            string output; //date output

            output = Month.ToString("D2") + "/" + Day.ToString("D2") + "/" + Year.ToString("D4");

            return output;
        }
    }
}
