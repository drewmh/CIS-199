﻿//Grading ID: N7591
//Lab number 2, due Sunday Feb 3
//Course section: CIS 199 - 75
//Brief description: This program calculates the correct tip you may want to leave for a meal.

using System;
using System.Windows.Forms;

namespace Lab02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //Event: When you press this button, it shows the denominations of listed tips.
        private void button1_Click(object sender, EventArgs e)
        {
            double Cost; //Cost of the meal. User's input.
            double LowTip; //Designation for the lowest tip percentage calculation.
            double MidTip; //Designation for the middle tip percentage calculation.
            double HighTip; //Designation for the highest tip percentage calculation.

            Cost = double.Parse(CostinText.Text);
            LowTip = Cost * .15;
            MidTip = Cost * .18;
            HighTip = Cost * .20;

            LowTipLbl.Text = $"{LowTip}";
            MidTipLbl.Text = $"{MidTip}";
            HighTipLbl.Text = $"{HighTip}";



        }
    }
}
