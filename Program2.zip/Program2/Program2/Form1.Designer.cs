﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.Prompt1 = new System.Windows.Forms.Label();
            this.Prompt2 = new System.Windows.Forms.Label();
            this.incomeInput = new System.Windows.Forms.TextBox();
            this.statusBox = new System.Windows.Forms.GroupBox();
            this.singleButton = new System.Windows.Forms.RadioButton();
            this.jointButton = new System.Windows.Forms.RadioButton();
            this.headButton = new System.Windows.Forms.RadioButton();
            this.sepButton = new System.Windows.Forms.RadioButton();
            this.result1 = new System.Windows.Forms.Label();
            this.rateOutput = new System.Windows.Forms.Label();
            this.result2 = new System.Windows.Forms.Label();
            this.taxOutput = new System.Windows.Forms.Label();
            this.calculate = new System.Windows.Forms.Button();
            this.statusBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(40, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(213, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Find Your Tax Bracket and Taxable Income";
            // 
            // Prompt1
            // 
            this.Prompt1.AutoSize = true;
            this.Prompt1.Location = new System.Drawing.Point(12, 35);
            this.Prompt1.Name = "Prompt1";
            this.Prompt1.Size = new System.Drawing.Size(132, 13);
            this.Prompt1.TabIndex = 1;
            this.Prompt1.Text = "Enter your taxable income:";
            // 
            // Prompt2
            // 
            this.Prompt2.AutoSize = true;
            this.Prompt2.Location = new System.Drawing.Point(12, 69);
            this.Prompt2.Name = "Prompt2";
            this.Prompt2.Size = new System.Drawing.Size(124, 13);
            this.Prompt2.TabIndex = 2;
            this.Prompt2.Text = "Choose your filing status:";
            this.Prompt2.Click += new System.EventHandler(this.label2_Click);
            // 
            // incomeInput
            // 
            this.incomeInput.Location = new System.Drawing.Point(150, 32);
            this.incomeInput.Name = "incomeInput";
            this.incomeInput.Size = new System.Drawing.Size(100, 20);
            this.incomeInput.TabIndex = 3;
            // 
            // statusBox
            // 
            this.statusBox.Controls.Add(this.singleButton);
            this.statusBox.Controls.Add(this.jointButton);
            this.statusBox.Controls.Add(this.headButton);
            this.statusBox.Controls.Add(this.sepButton);
            this.statusBox.Location = new System.Drawing.Point(33, 94);
            this.statusBox.Name = "statusBox";
            this.statusBox.Size = new System.Drawing.Size(217, 116);
            this.statusBox.TabIndex = 4;
            this.statusBox.TabStop = false;
            this.statusBox.Text = "Filing Status";
            this.statusBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // singleButton
            // 
            this.singleButton.AutoSize = true;
            this.singleButton.Location = new System.Drawing.Point(6, 19);
            this.singleButton.Name = "singleButton";
            this.singleButton.Size = new System.Drawing.Size(54, 17);
            this.singleButton.TabIndex = 5;
            this.singleButton.TabStop = true;
            this.singleButton.Text = "Single";
            this.singleButton.UseVisualStyleBackColor = true;
            // 
            // jointButton
            // 
            this.jointButton.AutoSize = true;
            this.jointButton.Location = new System.Drawing.Point(6, 42);
            this.jointButton.Name = "jointButton";
            this.jointButton.Size = new System.Drawing.Size(119, 17);
            this.jointButton.TabIndex = 6;
            this.jointButton.TabStop = true;
            this.jointButton.Text = "Married Filing Jointly";
            this.jointButton.UseVisualStyleBackColor = true;
            // 
            // headButton
            // 
            this.headButton.AutoSize = true;
            this.headButton.Location = new System.Drawing.Point(6, 65);
            this.headButton.Name = "headButton";
            this.headButton.Size = new System.Drawing.Size(117, 17);
            this.headButton.TabIndex = 7;
            this.headButton.TabStop = true;
            this.headButton.Text = "Head of Household";
            this.headButton.UseVisualStyleBackColor = true;
            // 
            // sepButton
            // 
            this.sepButton.AutoSize = true;
            this.sepButton.Location = new System.Drawing.Point(6, 88);
            this.sepButton.Name = "sepButton";
            this.sepButton.Size = new System.Drawing.Size(140, 17);
            this.sepButton.TabIndex = 8;
            this.sepButton.TabStop = true;
            this.sepButton.Text = "Married Filing Separately";
            this.sepButton.UseVisualStyleBackColor = true;
            // 
            // result1
            // 
            this.result1.AutoSize = true;
            this.result1.Location = new System.Drawing.Point(36, 264);
            this.result1.Name = "result1";
            this.result1.Size = new System.Drawing.Size(97, 13);
            this.result1.TabIndex = 5;
            this.result1.Text = "Marginal Tax Rate:";
            // 
            // rateOutput
            // 
            this.rateOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rateOutput.Location = new System.Drawing.Point(139, 263);
            this.rateOutput.Name = "rateOutput";
            this.rateOutput.Size = new System.Drawing.Size(100, 19);
            this.rateOutput.TabIndex = 6;
            // 
            // result2
            // 
            this.result2.AutoSize = true;
            this.result2.Location = new System.Drawing.Point(82, 303);
            this.result2.Name = "result2";
            this.result2.Size = new System.Drawing.Size(51, 13);
            this.result2.TabIndex = 7;
            this.result2.Text = "Tax Due:";
            // 
            // taxOutput
            // 
            this.taxOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOutput.Location = new System.Drawing.Point(139, 302);
            this.taxOutput.Name = "taxOutput";
            this.taxOutput.Size = new System.Drawing.Size(100, 20);
            this.taxOutput.TabIndex = 8;
            // 
            // calculate
            // 
            this.calculate.Location = new System.Drawing.Point(85, 216);
            this.calculate.Name = "calculate";
            this.calculate.Size = new System.Drawing.Size(75, 23);
            this.calculate.TabIndex = 9;
            this.calculate.Text = "Calculate";
            this.calculate.UseVisualStyleBackColor = true;
            this.calculate.Click += new System.EventHandler(this.calculate_Click);
            // 
            // Program2
            // 
            this.AcceptButton = this.calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 358);
            this.Controls.Add(this.calculate);
            this.Controls.Add(this.taxOutput);
            this.Controls.Add(this.result2);
            this.Controls.Add(this.rateOutput);
            this.Controls.Add(this.result1);
            this.Controls.Add(this.statusBox);
            this.Controls.Add(this.incomeInput);
            this.Controls.Add(this.Prompt2);
            this.Controls.Add(this.Prompt1);
            this.Controls.Add(this.Title);
            this.Name = "Program2";
            this.Text = "Program2";
            this.statusBox.ResumeLayout(false);
            this.statusBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label Prompt1;
        private System.Windows.Forms.Label Prompt2;
        private System.Windows.Forms.TextBox incomeInput;
        private System.Windows.Forms.GroupBox statusBox;
        private System.Windows.Forms.RadioButton singleButton;
        private System.Windows.Forms.RadioButton jointButton;
        private System.Windows.Forms.RadioButton headButton;
        private System.Windows.Forms.RadioButton sepButton;
        private System.Windows.Forms.Label result1;
        private System.Windows.Forms.Label rateOutput;
        private System.Windows.Forms.Label result2;
        private System.Windows.Forms.Label taxOutput;
        private System.Windows.Forms.Button calculate;
    }
}

