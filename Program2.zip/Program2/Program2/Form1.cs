﻿/* Grading ID: N7591
 * Program #2
 * Due March 5, 2019
 * Section CIS 199-75
 * This program will tell you what tax bracket you are in, as well as what tax is due.
 */
using System;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        // Pressing this button will calculate the tax information.
        private void calculate_Click(object sender, EventArgs e)
        {
            double income; // User's input
            double taxDue; // Calculation for how much money is due from initial income
            const double TAX_RATE1 = .1; // First tax bracket
            const double TAX_RATE2 = .12; // Second tax bracket
            const double TAX_RATE3 = .22; // Third
            const double TAX_RATE4 = .24; // Fourth
            const double TAX_RATE5 = .32; // Fifth
            const double TAX_RATE6 = .35; // Sixth
            const double TAX_RATE7 = .37; // Seventh
            const double SINGLE_THRESH1 = 9700; // End of 1st single tax bracket
            const double SINGLE_THRESH2 = 39475; // End of 2nd single tax bracket
            const double SINGLE_THRESH3 = 84200; // End of 3rd single tax bracket
            const double SINGLE_THRESH4 = 160725; // End of 4th single tax bracket
            const double SINGLE_THRESH5 = 204100; // End of 5th single tax bracket
            const double SINGLE_THRESH6 = 510300; // End of 6th single tax bracket
            const double JOINT_THRESH1 = 19400; // End of 1st joint tax bracket
            const double JOINT_THRESH2 = 78950; // End of 2nd joint tax bracket
            const double JOINT_THRESH3 = 168400; // End of 3rd joint tax bracket
            const double JOINT_THRESH4 = 321450; // End of 4th joint tax bracket
            const double JOINT_THRESH5 = 408200; // End of 5th joint tax bracket
            const double JOINT_THRESH6 = 612350; // End of 6th joint tax bracket
            const double HEAD_THRESH1 = 13850; // End of 1st head of household tax bracket
            const double HEAD_THRESH2 = 52850; // End of 2nd head of household tax bracket
            const double HEAD_THRESH3 = 84200; // End of 3rd head of household tax bracket
            const double HEAD_THRESH4 = 160700; // End of 4th head of household tax bracket
            const double HEAD_THRESH5 = 204100; // End of 5th head of household tax bracket
            const double HEAD_THRESH6 = 510300; // End of 6th head of household tax bracket
            const double SEP_THRESH1 = 9700; // End of 1st separate tax bracket
            const double SEP_THRESH2 = 39475; // End of 2nd separate tax bracket
            const double SEP_THRESH3 = 84200; // End of 3rd separate tax bracket
            const double SEP_THRESH4 = 160725; // End of 4th separate tax bracket
            const double SEP_THRESH5 = 204100; // End of 5th separate tax bracket
            const double SEP_THRESH6 = 306175; // End of 6th separate tax bracket

            // Gathering user input.
            if (double.TryParse(incomeInput.Text, out income))
            {
                income = double.Parse(incomeInput.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid income.");
            }

            // Begin a long series of if statements that determine tax rate, and amount due.
            if (singleButton.Checked)
            {
                if (income <= SINGLE_THRESH1)
                {
                    taxDue = income * TAX_RATE1;
                    rateOutput.Text = $"{TAX_RATE1:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SINGLE_THRESH2)
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (income - SINGLE_THRESH1) * TAX_RATE2;
                    rateOutput.Text = $"{TAX_RATE2:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SINGLE_THRESH3)
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (SINGLE_THRESH2-SINGLE_THRESH1) * TAX_RATE2 + (income-SINGLE_THRESH2) * TAX_RATE3;
                    rateOutput.Text = $"{TAX_RATE3:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SINGLE_THRESH4)
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (SINGLE_THRESH2 - SINGLE_THRESH1) * TAX_RATE2 + (SINGLE_THRESH3 - SINGLE_THRESH2) * TAX_RATE3 + (income - SINGLE_THRESH3) * TAX_RATE4;
                    rateOutput.Text = $"{TAX_RATE4:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SINGLE_THRESH5)
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (SINGLE_THRESH2 - SINGLE_THRESH1) * TAX_RATE2 + (SINGLE_THRESH3 - SINGLE_THRESH2) * TAX_RATE3 + (SINGLE_THRESH4-SINGLE_THRESH3) * TAX_RATE4 + (income - SINGLE_THRESH4) * TAX_RATE5;
                    rateOutput.Text = $"{TAX_RATE5:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SINGLE_THRESH6)
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (SINGLE_THRESH2 - SINGLE_THRESH1) * TAX_RATE2 + (SINGLE_THRESH3 - SINGLE_THRESH2) * TAX_RATE3 + (SINGLE_THRESH4 - SINGLE_THRESH3) * TAX_RATE4 + (SINGLE_THRESH5-SINGLE_THRESH4) * TAX_RATE5 + (income - SINGLE_THRESH5) * TAX_RATE6;
                    rateOutput.Text = $"{TAX_RATE6:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else
                {
                    taxDue = SINGLE_THRESH1 * TAX_RATE1 + (SINGLE_THRESH2 - SINGLE_THRESH1) * TAX_RATE2 + (SINGLE_THRESH3 - SINGLE_THRESH2) * TAX_RATE3 + (SINGLE_THRESH4 - SINGLE_THRESH3) * TAX_RATE4 + (SINGLE_THRESH5 - SINGLE_THRESH4) * TAX_RATE5 + (SINGLE_THRESH6-SINGLE_THRESH5) * TAX_RATE6 + (income - SINGLE_THRESH6) * TAX_RATE7;
                    rateOutput.Text = $"{TAX_RATE7:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
            }
            else if (jointButton.Checked)
            {
                if (income <= JOINT_THRESH1)
                {
                    taxDue = income * TAX_RATE1;
                    rateOutput.Text = $"{TAX_RATE1:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= JOINT_THRESH2)
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (income - JOINT_THRESH1) * TAX_RATE2;
                    rateOutput.Text = $"{TAX_RATE2:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= JOINT_THRESH3)
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (JOINT_THRESH2 - JOINT_THRESH1) * TAX_RATE2 + (income - JOINT_THRESH2) * TAX_RATE3;
                    rateOutput.Text = $"{TAX_RATE3:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= JOINT_THRESH4)
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (JOINT_THRESH2 - JOINT_THRESH1) * TAX_RATE2 + (JOINT_THRESH3 - JOINT_THRESH2) * TAX_RATE3 + (income - JOINT_THRESH3) * TAX_RATE4;
                    rateOutput.Text = $"{TAX_RATE4:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= JOINT_THRESH5)
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (JOINT_THRESH2 - JOINT_THRESH1) * TAX_RATE2 + (JOINT_THRESH3 - JOINT_THRESH2) * TAX_RATE3 + (JOINT_THRESH4 - JOINT_THRESH3) * TAX_RATE4 + (income - JOINT_THRESH4) * TAX_RATE5;
                    rateOutput.Text = $"{TAX_RATE5:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= JOINT_THRESH6)
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (JOINT_THRESH2 - JOINT_THRESH1) * TAX_RATE2 + (JOINT_THRESH3 - JOINT_THRESH2) * TAX_RATE3 + (JOINT_THRESH4 - JOINT_THRESH3) * TAX_RATE4 + (JOINT_THRESH5 - JOINT_THRESH4) * TAX_RATE5 + (income - JOINT_THRESH5) * TAX_RATE6;
                    rateOutput.Text = $"{TAX_RATE6:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else
                {
                    taxDue = JOINT_THRESH1 * TAX_RATE1 + (JOINT_THRESH2 - JOINT_THRESH1) * TAX_RATE2 + (JOINT_THRESH3 - JOINT_THRESH2) * TAX_RATE3 + (JOINT_THRESH4 - JOINT_THRESH3) * TAX_RATE4 + (JOINT_THRESH5 - JOINT_THRESH4) * TAX_RATE5 + (JOINT_THRESH6 - JOINT_THRESH5) * TAX_RATE6 + (income - JOINT_THRESH6) * TAX_RATE7;
                    rateOutput.Text = $"{TAX_RATE7:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
            }
            else if (headButton.Checked)
            {
                if (income <= HEAD_THRESH1)
                {
                    taxDue = income * TAX_RATE1;
                    rateOutput.Text = $"{TAX_RATE1:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= HEAD_THRESH2)
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (income - HEAD_THRESH1) * TAX_RATE2;
                    rateOutput.Text = $"{TAX_RATE2:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= HEAD_THRESH3)
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (HEAD_THRESH2 - HEAD_THRESH1) * TAX_RATE2 + (income - HEAD_THRESH2) * TAX_RATE3;
                    rateOutput.Text = $"{TAX_RATE3:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= HEAD_THRESH4)
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (HEAD_THRESH2 - HEAD_THRESH1) * TAX_RATE2 + (HEAD_THRESH3 - HEAD_THRESH2) * TAX_RATE3 + (income - HEAD_THRESH3) * TAX_RATE4;
                    rateOutput.Text = $"{TAX_RATE4:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= HEAD_THRESH5)
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (HEAD_THRESH2 - HEAD_THRESH1) * TAX_RATE2 + (HEAD_THRESH3 - HEAD_THRESH2) * TAX_RATE3 + (HEAD_THRESH4 - HEAD_THRESH3) * TAX_RATE4 + (income - HEAD_THRESH4) * TAX_RATE5;
                    rateOutput.Text = $"{TAX_RATE5:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= HEAD_THRESH6)
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (HEAD_THRESH2 - HEAD_THRESH1) * TAX_RATE2 + (HEAD_THRESH3 - HEAD_THRESH2) * TAX_RATE3 + (HEAD_THRESH4 - HEAD_THRESH3) * TAX_RATE4 + (HEAD_THRESH5 - HEAD_THRESH4) * TAX_RATE5 + (income - HEAD_THRESH5) * TAX_RATE6;
                    rateOutput.Text = $"{TAX_RATE6:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else
                {
                    taxDue = HEAD_THRESH1 * TAX_RATE1 + (HEAD_THRESH2 - HEAD_THRESH1) * TAX_RATE2 + (HEAD_THRESH3 - HEAD_THRESH2) * TAX_RATE3 + (HEAD_THRESH4 - HEAD_THRESH3) * TAX_RATE4 + (HEAD_THRESH5 - HEAD_THRESH4) * TAX_RATE5 + (HEAD_THRESH6 - HEAD_THRESH5) * TAX_RATE6 + (income - HEAD_THRESH6) * TAX_RATE7;
                    rateOutput.Text = $"{TAX_RATE7:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
            }
            else if (sepButton.Checked)
            {
                if (income <= SEP_THRESH1)
                {
                    taxDue = income * TAX_RATE1;
                    rateOutput.Text = $"{TAX_RATE1:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SEP_THRESH2)
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (income - SEP_THRESH1) * TAX_RATE2;
                    rateOutput.Text = $"{TAX_RATE2:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SEP_THRESH3)
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (SEP_THRESH2 - SEP_THRESH1) * TAX_RATE2 + (income - SEP_THRESH2) * TAX_RATE3;
                    rateOutput.Text = $"{TAX_RATE3:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SEP_THRESH4)
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (SEP_THRESH2 - SEP_THRESH1) * TAX_RATE2 + (SEP_THRESH3 - SEP_THRESH2) * TAX_RATE3 + (income - SEP_THRESH3) * TAX_RATE4;
                    rateOutput.Text = $"{TAX_RATE4:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SEP_THRESH5)
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (SEP_THRESH2 - SEP_THRESH1) * TAX_RATE2 + (SEP_THRESH3 - SEP_THRESH2) * TAX_RATE3 + (SEP_THRESH4 - SEP_THRESH3) * TAX_RATE4 + (income - SEP_THRESH4) * TAX_RATE5;
                    rateOutput.Text = $"{TAX_RATE5:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else if (income <= SEP_THRESH6)
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (SEP_THRESH2 - SEP_THRESH1) * TAX_RATE2 + (SEP_THRESH3 - SEP_THRESH2) * TAX_RATE3 + (SEP_THRESH4 - SEP_THRESH3) * TAX_RATE4 + (SEP_THRESH5 - SEP_THRESH4) * TAX_RATE5 + (income - SEP_THRESH5) * TAX_RATE6;
                    rateOutput.Text = $"{TAX_RATE6:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
                else
                {
                    taxDue = SEP_THRESH1 * TAX_RATE1 + (SEP_THRESH2 - SEP_THRESH1) * TAX_RATE2 + (SEP_THRESH3 - SEP_THRESH2) * TAX_RATE3 + (SEP_THRESH4 - SEP_THRESH3) * TAX_RATE4 + (SEP_THRESH5 - SEP_THRESH4) * TAX_RATE5 + (SEP_THRESH6 - SEP_THRESH5) * TAX_RATE6 + (income - SEP_THRESH6) * TAX_RATE7;
                    rateOutput.Text = $"{TAX_RATE7:P0}";
                    taxOutput.Text = $"{taxDue:C}";
                }
            }
            else
            { MessageBox.Show("Please select a filing status."); }

        }
    }
}
