﻿/* Grading ID: N7591
lab number 8, due date 3/31/2019
course section CIS 199-75
This program will tell the user how much their money is worth now based on variables they input.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab08
{
    public partial class Lab8 : Form
    {
        public Lab8()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            double futureValInput; // input for the future value of the money
            double airInput; // input for the annual interest rate
            int noYearInput; // input for number of years
            double presentValue; // how much the money is worth now

            // parsing users input
            if (double.TryParse(futureValTxt.Text, out futureValInput))
            {
                futureValInput = double.Parse(futureValTxt.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid value.");
            }

            if (double.TryParse(airTxt.Text, out airInput))
            {
                airInput = double.Parse(airTxt.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid rate.");
            }

            if (int.TryParse(noYearTxt.Text, out noYearInput))
            {
                noYearInput = int.Parse(noYearTxt.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid number of years.");
            }

            // getting the values
            presentValue = CalcPresentValue(futureValInput, airInput, noYearInput);
            // outputting the value to GUI
            output.Text = $"{presentValue:C}";
        }

        public static double CalcPresentValue(double futureVal, double air, int noYear)
        {
            double presentVal; // what the money is worth now
            // calculations
            presentVal = (futureVal) / Math.Pow((1 + air), (noYear));
            return presentVal;
        }
    }
}
