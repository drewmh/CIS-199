﻿namespace Lab08
{
    partial class Lab8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValLbl = new System.Windows.Forms.Label();
            this.airLbl = new System.Windows.Forms.Label();
            this.noYearLbl = new System.Windows.Forms.Label();
            this.presentValLbl = new System.Windows.Forms.Label();
            this.output = new System.Windows.Forms.Label();
            this.futureValTxt = new System.Windows.Forms.TextBox();
            this.airTxt = new System.Windows.Forms.TextBox();
            this.noYearTxt = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValLbl
            // 
            this.futureValLbl.AutoSize = true;
            this.futureValLbl.Location = new System.Drawing.Point(12, 9);
            this.futureValLbl.Name = "futureValLbl";
            this.futureValLbl.Size = new System.Drawing.Size(70, 13);
            this.futureValLbl.TabIndex = 0;
            this.futureValLbl.Text = "Future Value:";
            // 
            // airLbl
            // 
            this.airLbl.AutoSize = true;
            this.airLbl.Location = new System.Drawing.Point(12, 43);
            this.airLbl.Name = "airLbl";
            this.airLbl.Size = new System.Drawing.Size(107, 13);
            this.airLbl.TabIndex = 1;
            this.airLbl.Text = "Annual Interest Rate:";
            // 
            // noYearLbl
            // 
            this.noYearLbl.AutoSize = true;
            this.noYearLbl.Location = new System.Drawing.Point(12, 79);
            this.noYearLbl.Name = "noYearLbl";
            this.noYearLbl.Size = new System.Drawing.Size(69, 13);
            this.noYearLbl.TabIndex = 2;
            this.noYearLbl.Text = "No. of Years:";
            // 
            // presentValLbl
            // 
            this.presentValLbl.AutoSize = true;
            this.presentValLbl.Location = new System.Drawing.Point(12, 131);
            this.presentValLbl.Name = "presentValLbl";
            this.presentValLbl.Size = new System.Drawing.Size(76, 13);
            this.presentValLbl.TabIndex = 3;
            this.presentValLbl.Text = "Present Value:";
            // 
            // output
            // 
            this.output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output.Location = new System.Drawing.Point(120, 121);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(100, 23);
            this.output.TabIndex = 4;
            // 
            // futureValTxt
            // 
            this.futureValTxt.Location = new System.Drawing.Point(120, 6);
            this.futureValTxt.Name = "futureValTxt";
            this.futureValTxt.Size = new System.Drawing.Size(100, 20);
            this.futureValTxt.TabIndex = 5;
            // 
            // airTxt
            // 
            this.airTxt.Location = new System.Drawing.Point(120, 40);
            this.airTxt.Name = "airTxt";
            this.airTxt.Size = new System.Drawing.Size(100, 20);
            this.airTxt.TabIndex = 6;
            // 
            // noYearTxt
            // 
            this.noYearTxt.Location = new System.Drawing.Point(120, 76);
            this.noYearTxt.Name = "noYearTxt";
            this.noYearTxt.Size = new System.Drawing.Size(100, 20);
            this.noYearTxt.TabIndex = 7;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(72, 167);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 8;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Lab8
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 196);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.noYearTxt);
            this.Controls.Add(this.airTxt);
            this.Controls.Add(this.futureValTxt);
            this.Controls.Add(this.output);
            this.Controls.Add(this.presentValLbl);
            this.Controls.Add(this.noYearLbl);
            this.Controls.Add(this.airLbl);
            this.Controls.Add(this.futureValLbl);
            this.Name = "Lab8";
            this.Text = "Lab8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValLbl;
        private System.Windows.Forms.Label airLbl;
        private System.Windows.Forms.Label noYearLbl;
        private System.Windows.Forms.Label presentValLbl;
        private System.Windows.Forms.Label output;
        private System.Windows.Forms.TextBox futureValTxt;
        private System.Windows.Forms.TextBox airTxt;
        private System.Windows.Forms.TextBox noYearTxt;
        private System.Windows.Forms.Button calcButton;
    }
}

