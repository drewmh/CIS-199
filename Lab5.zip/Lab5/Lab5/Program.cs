﻿/* Grading ID: N7591
 * Lab Number 5
 * Due March 3, 2019
 * Course Section CIS 199-75
 * This program calculates the mean of temperatures entered by the user.
 */

using static System.Console;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            int temp; // User's input for temperature
            bool valid = true; // Makes sure the temp. is a valid number
            const int LOW = -20; // Lowest temperature for validation
            const int HIGH = 120; // Highest temperature for validation
            double counter = 0; // Counts how many temps. have been entered
            double sum = 0; // Adds up the temps. entered
            double mean; // Will average out the temps. entered

            // Intro and Gathering Starting Information
            WriteLine("Enter temperatures from -20 to 130 (999 to stop)");
            WriteLine("");
            Write("Enter temperature: ");
            valid = int.TryParse(ReadLine(), out temp);

            // Begin loop, gathering info.
            while (temp != 999)
            {
                if (!valid || temp < LOW || temp > HIGH)
                {
                    WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature.");
                    Write("Enter temperature: ");
                    valid = int.TryParse(ReadLine(), out temp);
                }

                else
                {
                    ++counter;
                    sum += temp;
                    Write("Enter temperature: ");
                    valid = int.TryParse(ReadLine(), out temp);
                }
                }

            // Summary
            WriteLine("");
                mean = sum / counter;
                WriteLine($"You entered {counter} valid temperatures.");
                WriteLine($"The mean temperature is {mean:N1} degrees.");


            }
        }
    }

