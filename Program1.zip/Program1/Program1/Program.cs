﻿// Grading ID:
// Program 1
// Due Feb 12, 2019
// Course Section CIS 199-75

using static System.Console;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Carpet Price Estimator");
            WriteLine("");

            double MaxWidth; // variable
            double MaxLength; // variable
            double PricePYard; // price of carpet
            int Padding; // price of padding. Either 1 or 2 layers
            int FirstRoom; // 1 means first room. 0 later room in bid
            double SqYard; // square yard calculation
            const double TEN_PERCENT = 1.1; // waste calculation
            double CarpetCost; // total cost of carpeting
            const double PADDING_CHARGE = 2.75; // company's charge for padding per sq. yard
            double PaddingCost; // total cost of padding
            const double LABOR_CHARGE = 4.50; // company's charge for labor per sq. yard
            double LaborCost; // total cost of labor
            const double LABOR_1ROOM = 100.00; // if its 1st room, use this extra charge
            double TotalCost; // total cost of project

            string MaxWidthString; // user input
            string MaxLengthString; // user input
            string PriceString; // user input
            string PaddingString; // user input
            string FirstRoomString; // user input

            // Getting User Inputs
            Write("Enter the max width of room (in feet): ");
            MaxWidthString = ReadLine();
            MaxWidth = double.Parse(MaxWidthString);
            Write("Enter the max length of room (in feet): ");
            MaxLengthString = ReadLine();
            MaxLength = double.Parse(MaxLengthString);
            Write("Enter the carpet price (per sq. yard): ");
            PriceString = ReadLine();
            PricePYard = double.Parse(PriceString);
            Write("Enter layers of padding to use (1 or 2): ");
            PaddingString = ReadLine();
            Padding = int.Parse(PaddingString);
            Write("Is this the first room? (1 = YES, 0 = NO): ");
            FirstRoomString = ReadLine();
            FirstRoom = int.Parse(FirstRoomString);
            WriteLine("");

            //Calculations and Outputs =
            SqYard = MaxWidth * MaxLength / 9;
            WriteLine($"Sq. Yards Needed: {SqYard:N1}");

            CarpetCost = (SqYard * PricePYard) * TEN_PERCENT;
            WriteLine($"Carpet Cost:      {CarpetCost:C}");

            PaddingCost = (SqYard * PADDING_CHARGE) * (TEN_PERCENT) * (Padding);
            WriteLine($"Padding Cost:     {PaddingCost:C}");

            LaborCost = SqYard * LABOR_CHARGE;

            if (FirstRoom == 1)
                LaborCost = LABOR_1ROOM + (SqYard * LABOR_CHARGE);
            WriteLine($"Labor Cost:       {LaborCost:C}");

            TotalCost = CarpetCost + PaddingCost + LaborCost;
            WriteLine($"Total Cost:       {TotalCost:C}");
        
        }
    }
}
