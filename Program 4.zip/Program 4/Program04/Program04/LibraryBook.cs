﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program04
{
    public class LibraryBook
    {
        const int DEFAULT_YEAR = 2019; // default year for publication, if none specified
        bool CheckedOut; // is the book checked out, yes or no
        private string _bookTitle; // title of book
        private string _bookAuthor; // author of book
        private string _bookPub; // publisher of book
        private int _yearOfPub; // publication year
        private string _isbn; // call number for book

        public LibraryBook(string theTitle, string theAuthor, string thePub, int theYear, string theISBN)
        {
            BookTitle = theTitle;
            BookAuthor = theAuthor;
            BookPub = thePub;
            YearOfPub = theYear;
            ISBN = theISBN;
            ReturnToShelf();
        }

        //Pre Condition: Value unassigned.
        //PostCondition: Book title value assigned from array.
        public string BookTitle
        {
            get
            {
                return _bookTitle;
            }
            set
            {
                _bookTitle = value;
            }
        }

        //Pre Condition: Value unassigned.
        //PostCondition: Book author value assigned from array.
        public string BookAuthor
        {
            get
            {
                return _bookAuthor;
            }
            set
            {
                _bookAuthor = value;
            }
        }

        //Pre Condition: Value unassigned.
        //PostCondition: Book publisher value assigned from array.
        public string BookPub
        {
            get
            {
                return _bookPub;
            }
            set
            {
                _bookPub = value;
            }
        }

        //Pre Condition: Value unassigned.
        //PostCondition: Book year value assigned from array.
        public int YearOfPub
        {
            get
            {
                return _yearOfPub;
            }
            set
            {
                if (value >= 0)
                    _yearOfPub = value;
                else
                    _yearOfPub = DEFAULT_YEAR;
            }
        }

        //Pre Condition: Value unassigned.
        //PostCondition: ISBN value assigned from array.
        public string ISBN
        {
            get
            {
                return _isbn;
            }
            set
            {
                _isbn = value;
            }
        }

        //Pre Condition: Is book checked out?
        //PostCondition: Book is checked out.
        public void CheckOut()
        {
            CheckedOut = true;
        }

        //Pre Condition: Is book checked out?
        //PostCondition: Book has been returned.
        public void ReturnToShelf()
        {
            CheckedOut = false;
        }

        //Pre Condition: Book status unknown.
        //PostCondition: Sets book as either Checked out or not.
        public bool IsCheckedOut()
        {
            if (CheckedOut)
                return true;
            else
                return false;
        }

        // Sends info to console.
        public override string ToString()
        {
            string objectString = $"Book Title    : {BookTitle}" + Environment.NewLine + $"Book Author   : {BookAuthor}"
                + Environment.NewLine + $"Publisher     : {BookPub}" + Environment.NewLine + $"Copyright Year: {YearOfPub}"
                + Environment.NewLine + $"Call Number   : {ISBN}" + Environment.NewLine + $"Checked Out?  : {IsCheckedOut()}" + Environment.NewLine;
            return objectString;
        }
    }
}
