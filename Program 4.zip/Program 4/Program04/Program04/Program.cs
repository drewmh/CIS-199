﻿/* Grading ID: S5017
 * Program Number: 4
 * Due Date: December 1, 2021
 * Course Section: CIS 199-50
 */

using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program04
{
    class Program
    {
        static void Main(string[] args)
        {
            // List of books
            LibraryBook book1 = new LibraryBook("Lord of the Rings", "J.R.R. Tolkien", "Allen & Unwin", 1954, "0001");
            LibraryBook book2 = new LibraryBook("Crime and Punishment", "Fyodor Dostoyevsky", "The Russian Messenger", 1866, "0002");
            LibraryBook book3 = new LibraryBook("Moby Dick", "Herman Melville", "Richard Bentley", 1851, "0003");
            LibraryBook book4 = new LibraryBook("War and Peace", "Leo Tolstoy", "The Russian Messenger", 1869, "0004");
            LibraryBook book5 = new LibraryBook("Of Mice and Men", "John Steinbeck", "Covici Friede", 1937, "0005");

            // Put books in array
            LibraryBook[] books = { book1, book2, book3, book4, book5 };

            // Display books
            PrintBooks(books);

            // Make changes to books
            book2.BookPub = "Mr. Crain";
            book2.ISBN = "1234";
            book2.CheckOut();

            book3.BookTitle = "The Whale";
            book3.BookPub = "Mr. Harris";
            book3.CheckOut();

            WriteLine("-----Checked Out Books---------");
            WriteLine("");

            // Display changed & checked out books
            PrintBooks(books);

            // Return books
            book2.ReturnToShelf();
            book3.ReturnToShelf();

            WriteLine("-----Returned Books------------");
            WriteLine("");

            // Display again
            PrintBooks(books);
        }

            // Loop to write to console.
            static void PrintBooks(LibraryBook[] books)
            {
                foreach (LibraryBook libraryBook in books)
                {
                    WriteLine($"{libraryBook}");
                }
            }
    }
}
