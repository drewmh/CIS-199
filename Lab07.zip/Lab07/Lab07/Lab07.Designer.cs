﻿namespace Lab07
{
    partial class Lab07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prompt1 = new System.Windows.Forms.Label();
            this.userInput = new System.Windows.Forms.TextBox();
            this.calculate = new System.Windows.Forms.Button();
            this.prompt2 = new System.Windows.Forms.Label();
            this.gradeBox = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // prompt1
            // 
            this.prompt1.Location = new System.Drawing.Point(12, 39);
            this.prompt1.Name = "prompt1";
            this.prompt1.Size = new System.Drawing.Size(73, 44);
            this.prompt1.TabIndex = 0;
            this.prompt1.Text = "Enter number of words typed:";
            this.prompt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // userInput
            // 
            this.userInput.Location = new System.Drawing.Point(91, 51);
            this.userInput.Name = "userInput";
            this.userInput.Size = new System.Drawing.Size(100, 20);
            this.userInput.TabIndex = 1;
            // 
            // calculate
            // 
            this.calculate.Location = new System.Drawing.Point(59, 86);
            this.calculate.Name = "calculate";
            this.calculate.Size = new System.Drawing.Size(75, 23);
            this.calculate.TabIndex = 2;
            this.calculate.Text = "Calculate Grade";
            this.calculate.UseVisualStyleBackColor = true;
            this.calculate.Click += new System.EventHandler(this.calculate_Click);
            // 
            // prompt2
            // 
            this.prompt2.AutoSize = true;
            this.prompt2.Location = new System.Drawing.Point(21, 141);
            this.prompt2.Name = "prompt2";
            this.prompt2.Size = new System.Drawing.Size(39, 13);
            this.prompt2.TabIndex = 3;
            this.prompt2.Text = "Grade:";
            // 
            // gradeBox
            // 
            this.gradeBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeBox.Location = new System.Drawing.Point(91, 131);
            this.gradeBox.Name = "gradeBox";
            this.gradeBox.Size = new System.Drawing.Size(100, 23);
            this.gradeBox.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nimble Fingers Typing School";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lab07
            // 
            this.AcceptButton = this.calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(203, 195);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gradeBox);
            this.Controls.Add(this.prompt2);
            this.Controls.Add(this.calculate);
            this.Controls.Add(this.userInput);
            this.Controls.Add(this.prompt1);
            this.Name = "Lab07";
            this.Text = "Lab07";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label prompt1;
        private System.Windows.Forms.TextBox userInput;
        private System.Windows.Forms.Button calculate;
        private System.Windows.Forms.Label prompt2;
        private System.Windows.Forms.Label gradeBox;
        private System.Windows.Forms.Label label1;
    }
}

