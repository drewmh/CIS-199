﻿/* Grading ID: N7591
lab number 7, due date 3/24/2019
course section CIS 199-75
This program will tell the user what grade they got based on a numeric entry.
*/

using System;
using static System.Console;
using System.Windows.Forms;

namespace Lab07
{
    public partial class Lab07 : Form
    {
        public Lab07()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void calculate_Click(object sender, EventArgs e)
        {
            int wordsTyped; // User's input
            int[] wordMins = { 0, 16, 31, 51, 76 }; // Minimums for each letter grade
            string[] grades = { "F", "D", "C", "B", "A" }; // Corresponding letter grade
            bool found = false; // Determines whether or not a match between the user's input and a minimum has been found
            int index = wordMins.Length - 1; // Variable to determine where it is looking in the array

            if (int.TryParse(userInput.Text, out wordsTyped))
            {
                wordsTyped = int.Parse(userInput.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid result.");
            }
                                                           
            while (index >= 0 && !found)
            {
                if (wordsTyped >= wordMins[index])
                    found = true;
                else
                    --index;
            }

            if (found)
            gradeBox.Text = $"{grades[index]}";

        }
    }
}
