﻿/* Grading ID: N7591
lab number 4, due date 2/17/2019
course section CIS 199-75
This program will tell the user if they got accepted or rejected to college depending on a GPA and test score.
*/
using System;
using System.Windows.Forms;

namespace Lab4
{
    // Listing the counts outside the button
    public partial class Lab4 : Form
    {
        
         private int acceptCount = 1; // Counts the amount of acceptions
         private int rejectCount = 1; // Counts the amount of rejections
        
        public Lab4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        // Pressing this button will reveal if you were accepted or rejected, and tally up each acception or rejection
        private void Calculate_Click(object sender, EventArgs e)
        {
            double GPA; // User's GPA Entry
            double Score; // User's Test Score Entry
            const double GOOD_GPA = 3.0; // Constant for a good GPA to meet requirements
            const double OKAY_SCORE = 60; // Constant for an okay test score to meet requirements
            const double GOOD_SCORE = 80; // COnstant for a good test score to meet requirements

            // Receiving data from user.
            if (double.TryParse(TestScoreInput.Text, out Score))
            {
                Score = double.Parse(TestScoreInput.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid test score.");
            }

            if (double.TryParse(GPAInput.Text, out GPA))
            {
                GPA = double.Parse(GPAInput.Text);
            }
            else
            {
                MessageBox.Show("Enter a valid GPA.");
            }

            // Calculations and output
            if (GPA >= GOOD_GPA && Score >= OKAY_SCORE || GPA < GOOD_GPA && Score >= GOOD_SCORE)
            {
                AcceptReject.Text = "Accepted.";
                AcceptCountBox.Text = (acceptCount ++).ToString();
            }

            else
            {
                AcceptReject.Text = "Rejected.";
                RejectCountBox.Text = (rejectCount ++).ToString();
            }
        }

        private void GPAInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
